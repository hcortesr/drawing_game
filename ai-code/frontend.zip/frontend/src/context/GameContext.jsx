import React, { createContext, useContext, useState } from 'react'

const GameContext = createContext()

export const useGame = () => useContext(GameContext)

export const GameProvider = ({ children }) => {
  const [roomCode, setRoomCode] = useState('')
  const [playerName, setPlayerName] = useState('')
  const [isCreator, setIsCreator] = useState(false)
  const [players, setPlayers] = useState([])
  const [gameState, setGameState] = useState('home') // home, lobby, playing, leaderboard
  const [currentDrawer, setCurrentDrawer] = useState(null)
  const [wordToDraw, setWordToDraw] = useState('')
  const [scores, setScores] = useState({})
  const [round, setRound] = useState(1)
  const [timeLeft, setTimeLeft] = useState(80)

  const generateRoomCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const value = {
    roomCode, setRoomCode,
    playerName, setPlayerName,
    isCreator, setIsCreator,
    players, setPlayers,
    gameState, setGameState,
    currentDrawer, setCurrentDrawer,
    wordToDraw, setWordToDraw,
    scores, setScores,
    round, setRound,
    timeLeft, setTimeLeft,
    generateRoomCode
  }

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>
}